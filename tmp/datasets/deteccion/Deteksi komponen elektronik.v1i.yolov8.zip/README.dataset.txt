# Deteksi komponen  elektronik > 2022-12-09 12:58pm
https://universe.roboflow.com/yolopcv/deteksi-komponen-elektronik

Provided by a Roboflow user
License: CC BY 4.0

