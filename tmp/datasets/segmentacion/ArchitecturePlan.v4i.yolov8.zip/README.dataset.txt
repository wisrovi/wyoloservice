# ArchitecturePlan > 2024-04-15 9:36pm
https://universe.roboflow.com/architectureplan/architectureplan

Provided by a Roboflow user
License: MIT

